# esta função lê um arquivo SCO do MULTILOG ou do BILOG-MG
# prog = 'BLM' para BILOG-MG e 'MLM' para MULTILOG

ler.score = function (arq.sco, prog = 'BLM')
{
library (stringr)
if (prog == 'MLM')
  {
  library (data.table)
  escore = fread (arq.sco, header = F, data.table = F)
  }

if (prog == 'BLM')
{
  # ler arquivo SCO
  dados2. = readLines(arq.sco)
  tail (dados2.)

  dados2 <- do.call(rbind,
                    lapply(split(dados2., rep(1:(length(dados2.)/2), each = 2)),
                           function(x)cbind(x[1], x[2])))

  dados2 = dados2[c (-1, -2),]
  head (dados2)

  escore = data.frame (
    as.numeric (str_sub(dados2, 1, 5)), # 5
    str_sub(dados2, 6, 35), # 30
    as.numeric (str_sub(dados2[,2], 1, 6)), # 6
    str_sub(dados2[,2], 7, 7), # 1
    str_sub(dados2[,2], 8, 15), # 8
    as.numeric (str_sub(dados2[,2], 16, 20)), # 5
    as.numeric (str_sub(dados2[,2], 21, 25)), # 5
    as.numeric (str_sub(dados2[,2], 26, 35)), # 10
    as.numeric (str_sub(dados2[,2], 36, 47)), # 12
    as.numeric (str_sub(dados2[,2], 38, 49)), # 12
    str_sub(dados2[,2], 50, 50), # 1
    as.numeric (str_sub(dados2[,2], 51, 60)), # 10
    as.numeric (str_sub(dados2[,2], 61, 70)) # 10
  )

  names (escore) = c("Grupo", "Inscrição", "Peso", "Calibração", "Teste", "Tentativa", "Acerto", "Porcentagem",
                     "Proficiência", "Erro", "Estimação do erro", "Ajuste do grupo", "Probabilidade do padrão")

}

return(escore)
}
