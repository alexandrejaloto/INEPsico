# lê arquivo PAR gerado pelo MULTILOG

ler.par.multi = function (arquivo, categorias)
{
par. = read.fwf(arquivo, widths = rep (12, categorias))
par = par. [-dim(par.)[1],]
return(par)
}
