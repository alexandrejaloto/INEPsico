# esta função retorna a frequência dos padrões de resposta em cada nível da escala
# escore = vetor com os escores
# peso = vetor com o peso de cada escore
# niv = os níveis da escala
# met = o método de alocação, segundo o relatório de 2014 da ANA

freq.nivel = function(score, peso = 1, niv = seq (-2, 2, .25), met = 3)
{
library (dplyr)

# determinar os níveis dos pdrões de resposta
aloca = aloca.pessoa (score, niv = niv, met = met)

# criar objeto com as informações necessárias
niveis. = data.frame (score, peso, aloca$niveis[,1])
names (niveis.) = c ('Escore', 'Peso', 'Nivel')

niveis = niveis. %>%
  group_by (Nivel) %>%
  summarize (Frequencia = sum(Peso)/ (sum(niveis.$Peso)))
return (niveis)
}
