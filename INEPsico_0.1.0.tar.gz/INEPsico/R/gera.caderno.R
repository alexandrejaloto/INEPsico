### Esta função gera uma lista. Cada elemento da lista corresponde à estrutura de cada
### disciplina da prova aplicada. Mais especificamente, essa estrutura corresponde à
### composição de cada caderno de uma disciplina

# arq.itens = arquivo(s) com as informações dos itens
# arq.bib = arquivo com a estrutura do BIB
# disc.cad = quantidade de disciplinas em cada caderno

gera.caderno = function (arq.itens, arq.bib, disc.cad = 2)

{
# ler estrutura do BIB
estrutura = read.table (arq.bib, sep = ";", header = TRUE)

# nomes das disciplinas
disciplinas = as.character (unique (unlist (estrutura[,2:(disc.cad+1)])))

# número total de cadernos
tot.cad = max (estrutura$Caderno)

# quantidade de blocos por caderno
blocos.cad = (dim(estrutura)[2] - (2 + disc.cad) + 1)

# quantidade de blocos de cada disciplina em cada caderno
blocos.disc = blocos.cad/disc.cad

# quantidade de blocos de cada disciplina
blocos = max (estrutura [,(2 + disc.cad):dim(estrutura)[2]])

################################# COLOCAR OS ARQUIVOS COM ITENS UM EMBAIXO DO OUTRO E COM UMA COLUNA INDICANDO A DISCIPLINA ############################################

results = list()
itens = as.data.frame (matrix (ncol = 8))

for (i in 1:disc.cad)
{
  nome = paste ("itens", i, sep = "")
  results[[nome]] = read.table (arq.itens[i], header = TRUE, sep = ";")
  results[[nome]]$Disciplina = disciplinas[i]
  names (itens) = names (results[[nome]])
  itens = rbind (itens, results[[nome]])
}

itens = itens [2:dim(itens)[1],]

################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################

cad.disc2 = list()
cad.disc = list()
est.disc = list()

for (i in 1:length (disciplinas))
{
  for (x in 1:tot.cad)
  {

    for (j in 2:disc.cad)
    {
      disc = subset (itens, Disciplina == disciplinas[i])			# selecionar os itens de cada disciplina
      cad.disc2[[disciplinas[i]]] = subset (estrutura, estrutura[,2] == disciplinas[i])	# selecionar os cadernos de cada disciplina
      cad.disc[[disciplinas[i]]] = data.frame (cad.disc2[[disciplinas[i]]][,1], cad.disc2[[disciplinas[i]]][,2], cad.disc2[[disciplinas[i]]][,2+disc.cad], cad.disc2[[disciplinas[i]]][,2+disc.cad+1])	# montar tabela com Caderno, Disciplina e Blocos da disciplina no caderno

      cad.disc2[[disciplinas[i]]] = subset (estrutura, estrutura[,1+j] == disciplinas[i])	# selecionar os cadernos de cada disciplina
      cad.disc3 = data.frame (cad.disc2[[disciplinas[i]]][,1], cad.disc2[[disciplinas[i]]][,1+j], cad.disc2[[disciplinas[i]]][,2+disc.cad+(blocos.disc*(j-1))], cad.disc2[[disciplinas[i]]][,2+disc.cad+(blocos.disc*(j-1))+1])
      names (cad.disc3) = names (cad.disc[[disciplinas[i]]])
      cad.disc[[disciplinas[i]]] = rbind (cad.disc[[disciplinas[i]]], cad.disc3)	# montar tabela com Caderno, Disciplina e Blocos da disciplina no caderno
    }

    names (cad.disc[[disciplinas[i]]]) = c ("Caderno", "Disciplina", "Bloco1", "Bloco2")

    bl1 = subset (itens, Bloco == cad.disc [[disciplinas[i]]][x,3] & Disciplina == disciplinas[i])	# primeiro bloco do caderno
    bl2 = subset (itens, Bloco == cad.disc [[disciplinas[i]]][x,4] & Disciplina == disciplinas[i])	# segundo bloco do caderno
    cad = cbind (rbind (bl1, bl2), cad.disc [[disciplinas[i]]][x,1])	# juntar os dois e adicionar uma coluna com o número do caderno
    cab = c (names (itens), "Caderno")
    names (cad) = cab
    nome.disc = disciplinas[i]

    est.disc [[nome.disc]] = rbind (est.disc[[nome.disc]], cad)	# montar a estrutura dos cadernos da disciplina

  }

  est.disc[[nome.disc]] = est.disc[[nome.disc]][order (est.disc[[nome.disc]]$Caderno),]

  names (est.disc[[nome.disc]]) = c (names (itens), "Caderno")
#  write.table (est.disc[[nome.disc]], file = arquivo[i], sep = ";", col.names = TRUE, row.names = FALSE)
}

return (est.disc)
}
