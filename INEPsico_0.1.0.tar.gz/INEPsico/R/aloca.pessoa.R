# esta função posiciona as pessoas nos níveis da escala
# score = vetor com os escores
# niv = os níveis da escala
# met = o método de alocação, segundo o relatório de 2014 da ANA

aloca.pessoa = function (score, niv = seq (-2, 2, .25), met = 3)
{
  # cut segundo os niveis

  escore = list()
  escore$theta = score

  # caso o método para alocação seja o da opção 1 do relatório da ANA 2014
    if (met == 1)
  {
      escore$niveis = data.frame (cut (escore$theta, c (-Inf, niv), labels = niv))

    # caso o método para alocação seja o da opção 3 do relatório da ANA 2014
  } else if (met == 3) {
      escore$niveis = data.frame (cut (escore$theta, c (-Inf, niv), labels = niv))
  }
  escore$theta = data.frame (escore$theta)

  names (escore$theta) = "Escore"
  names (escore$niveis) = "Nivel"
  # print("Gerou-se um objeto do tipo list com duas data.frame ('theta' e 'niveis')")
  return (escore)

}
