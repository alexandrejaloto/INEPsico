adeq.par = function (arq.par, a = list(.45, 4), b = list(-4, 4), c = list(0, .45), salvar = FALSE)
{
par. = ler_PAR (arq.par)

# verificar se há algum item que estourou na calibração
if (which (par.$ERRO_INTERCEPTO == '**********') > 0)
{
  warning("Um ou mais itens nao calibraram adequadamente e nao foram incluidos nesta analise. Exclua esse(s) item(ns) e rode a calibracao novamente.")
#       call. = FALSE)
}

# selecionar somente os itens novos, ou seja, que tiveram erro != 0; eliminar também os itens que estouraram, ou seja, tiveram erro = '**********'
# há diferença entre as duas linhas abaixo porque em caso de um item estourar, o erro padrão é dado como ******, portanto o R lê como 'factor' e não como 'numeric'
par = subset (par., ERRO_INTERCEPTO != "   0.00000" & ERRO_INTERCEPTO != "**********")
par = subset (par, ERRO_INTERCEPTO != 0)

# transformar em 'numeric' o erro do parâmetro b, caso não seja
if (class (par$ERRO_B) == "factor")
{
  par$ERRO_B = as.numeric (as.character (par$ERRO_B))
}


# selecionar itens com a fora do intervalo adequado e inserir o motivo de abandono
a.fora.menor = subset (par, PAR_A < a[1])
a.fora.maior = subset (par, PAR_A > a[2])

# caso haja algum item nessa condição, inserir o motivo
if (dim (a.fora.menor)[1] != 0)
{
  a.fora.menor$MOTIVO = paste ("a < ", a[1], sep = "")
}

if (dim (a.fora.maior)[1] != 0)
{
  a.fora.maior$MOTIVO = paste ("a > ", a[2], sep = "")
}

# selecionar itens com b fora do intervalo adequado e inserir o motivo de abandono
b.fora.menor = subset (par, PAR_B < b[1])
b.fora.maior = subset (par, PAR_B > b[2])

if (dim (b.fora.menor)[1] != 0)
{
  b.fora.menor$MOTIVO = paste ("b < ", b[1], sep = "")
}

if (dim (b.fora.maior)[1] != 0)
{
  b.fora.maior$MOTIVO = paste ("b > ", b[2], sep = "")
}

# selecionar itens com c fora do intervalo adequado e inserir o motivo de abandono
c.fora.maior = subset (par, PAR_C < c[1])
c.fora.menor = subset (par, PAR_C > c[2])

if (dim (c.fora.menor)[1] != 0)
{
  c.fora.menor$MOTIVO = paste ("c < ", c[1], sep = "")
}

if (dim (c.fora.maior)[1] != 0)
{
  c.fora.maior$MOTIVO = paste ("c > ", c[2], sep = "")
}

# juntar todos os itens que estão fora do intervalo
todos.fora = rbind (a.fora.menor, a.fora.maior, b.fora.menor, b.fora.maior, c.fora.menor, c.fora.maior)

# criar tabela com os num_itens e com o motivo do abandono
fora = data.frame ('ITEM' = rownames (todos.fora), 'MOTIVO' = todos.fora$MOTIVO)

# salvar o arquivo
if (salvar == TRUE)
  {
  write.table (fora, "ITENS_FORA_INTERVALO.txt", sep = "\t", row.names = F, quote = F)
  }
return (fora)
}
