﻿gera.caderno = function()


########################### PARA GERAR UM ARQUIVO COM A SEQUENCIA DE ITENS DE CADA CADERNO ###########################
########################### A PARTIR DA INFORMAÇÃO DO BLOCO E DA POSIÇÃO QUE O ITEM OCUPA EM CADA BLOCO ###########################
#library (Deducer)
#library (gdata)
#library (stringr)
#library (stringi)





setwd (diretorio)


################################# COLOCAR OS ARQUIVOS COM ITENS UM EMBAIXO DO OUTRO E COM UMA COLUNA INDICANDO A DISCIPLINA ############################################
################################# COLOCAR OS ARQUIVOS COM ITENS UM EMBAIXO DO OUTRO E COM UMA COLUNA INDICANDO A DISCIPLINA ############################################
################################# COLOCAR OS ARQUIVOS COM ITENS UM EMBAIXO DO OUTRO E COM UMA COLUNA INDICANDO A DISCIPLINA ############################################


results = list()
itens = as.data.frame (matrix (ncol = 8))

for (i in 1:length(arq.itens))
{
  nome = paste ("itens", i, sep = "")
  results[[nome]] = read.table (arq.itens[i], header = TRUE, sep = ";")
  results[[nome]]$Disciplina = disciplinas[i]
  names (itens) = names (results[[nome]])
  itens = rbind (itens, results[[nome]])
}

itens = itens [2:dim(itens)[1],]

################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################
################################# CHAMAR DETERMINADO CADERNO E COLOCAR OS ITENS CORRESPONDENTES (UMA ÚNICA TABELA POR DISCIPLINA COM TODA A INFORMAÇÃO) #################################

estrutura = read.table (arq.estrutura, sep = ";", header = TRUE)

cad.disc2 = list()
cad.disc = list()
est.disc = list()

for (i in 1:length (disciplinas))
{
  for (x in 1:tot.cad)
  {

    for (j in 2:disc.cad)
    {
      disc = subset (itens, Disciplina == disciplinas[i])			# selecionar os itens de cada disciplina
      cad.disc2[[disciplinas[i]]] = subset (estrutura, estrutura[,2] == disciplinas[i])	# selecionar os cadernos de cada disciplina
      cad.disc[[disciplinas[i]]] = data.frame (cad.disc2[[disciplinas[i]]][,1], cad.disc2[[disciplinas[i]]][,2], cad.disc2[[disciplinas[i]]][,2+disc.cad], cad.disc2[[disciplinas[i]]][,2+disc.cad+1])	# montar tabela com Caderno, Disciplina e Blocos da disciplina no caderno

      cad.disc2[[disciplinas[i]]] = subset (estrutura, estrutura[,1+j] == disciplinas[i])	# selecionar os cadernos de cada disciplina
      cad.disc3 = data.frame (cad.disc2[[disciplinas[i]]][,1], cad.disc2[[disciplinas[i]]][,1+j], cad.disc2[[disciplinas[i]]][,2+disc.cad+(blocos.disc*(j-1))], cad.disc2[[disciplinas[i]]][,2+disc.cad+(blocos.disc*(j-1))+1])
      names (cad.disc3) = names (cad.disc[[disciplinas[i]]])
      cad.disc[[disciplinas[i]]] = rbind (cad.disc[[disciplinas[i]]], cad.disc3)	# montar tabela com Caderno, Disciplina e Blocos da disciplina no caderno
    }

    names (cad.disc[[disciplinas[i]]]) = c ("Caderno", "Disciplina", "Bloco1", "Bloco2")

    bl1 = subset (itens, Bloco == cad.disc [[disciplinas[i]]][x,3] & Disciplina == disciplinas[i])	# primeiro bloco do caderno
    bl2 = subset (itens, Bloco == cad.disc [[disciplinas[i]]][x,4] & Disciplina == disciplinas[i])	# segundo bloco do caderno
    cad = cbind (rbind (bl1, bl2), cad.disc [[disciplinas[i]]][x,1])	# juntar os dois e adicionar uma coluna com o número do caderno
    cab = c (names (itens), "Caderno")
    names (cad) = cab
    nome.disc = disciplinas[i]

    est.disc [[nome.disc]] = rbind (est.disc[[nome.disc]], cad)	# montar a estrutura dos cadernos da disciplina

  }

  est.disc[[nome.disc]] = est.disc[[nome.disc]][order (est.disc[[nome.disc]]$Caderno),]

  names (est.disc[[nome.disc]]) = c (names (itens), "Caderno")
  write.table (est.disc[[nome.disc]], file = arquivo[i], sep = ";", col.names = TRUE, row.names = FALSE)
}




########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################
########################### GERAR OS FORM NO BILOG (UTILIZANDO O NUMBILOG) ###########################

for (j in 1:length (disciplinas))
{
  caderno = read.table (arquivo[j], sep = ";", header = TRUE)

  num.bilog = sprintf ("%03s", caderno [,6]) # num_bilog com 3 caracteres

  caderno [,6] = num.bilog

  num = matrix (ncol = 2*num.itens+2, nrow = tot.cad)
  num [,2*num.itens+2] = ");"

  arquivo.form = file (form[j], "w+")		# criar arquivo para salvar os forms

  for (i in 0:(tot.cad-1))
  {
    a = i*2*num.itens + 1
    b = i*2*num.itens + 2*num.itens
    num [i+1,2] = caderno [a,6]
    num [i+1,3:(2*num.itens+1)] = paste (", ", caderno [(a+1):b,6], sep = "")
    num [i+1, 1] = paste (">FORM", i+cad.1[j], " LENGTH= ", 2*num.itens, ", INUMBERS=(", sep = "")

    cat ( str_wrap (paste (num [i+1,], collapse = ""), width = 60), "\n", file = arquivo.form)		# escrever os forms no arquivo

  }


  # write.fwf (num, form[j], sep = "", colnames = FALSE, rownames = FALSE)

}



########################### GERAR OS ARQUIVOS DE GABARITO ###########################
########################### GERAR OS ARQUIVOS DE GABARITO ###########################
########################### GERAR OS ARQUIVOS DE GABARITO ###########################
########################### GERAR OS ARQUIVOS DE GABARITO ###########################
########################### GERAR OS ARQUIVOS DE GABARITO ###########################
########################### GERAR OS ARQUIVOS DE GABARITO ###########################



for (j in 1:length (disciplinas))
{
  caderno = read.table (arquivo[j], sep = ";", header = TRUE)

  gab = matrix (ncol = 2*num.itens+1, nrow = tot.cad)

  for (i in 0:(tot.cad-1))
  {

    a = i*2*num.itens + 1
    b = i*2*num.itens + 2*num.itens
    gab [i+1,2:(2*num.itens+1)] = as.character (caderno [a:b,4])
    gab [i+1, 1] = paste (sprintf ("%03s", i+cad.1[j]), stri_dup (" ", carac[j]-3), sep="")
  }
  write.fwf (gab, arq.gab[j], sep = "", colnames = FALSE, rownames = FALSE)
}

