ler_PAR = function (arquivo)
{
  par = read.fwf (arquivo, skip = 4, widths = c (8, 8, rep (10, 12), 10, 4, 1, 1))
  names (par) = c ('ITEM', 'TESTE', 'INTERCEPTO', 'ERRO_INTERCEPTO', 'PAR_A', 'ERRO_A', 'PAR_B', 'ERRO_B', 'CARGA_FATORIAL', 'ERRO_CARGA', 'PAR_C', 'ERRO_C',
                   'DRIFT', 'ERRO_DRIFT', 'NA', 'NUM_BILOG', 'RESP', 'NA2')
  par = par [, c(-15, -18)]
  return (par)
}
