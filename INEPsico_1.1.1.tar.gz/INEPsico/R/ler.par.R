ler.par = function (arq.par, prog = 'BLM', categorias)
{
if (prog == 'BLM')
{
  par = read.fwf (arq.par, skip = 4, widths = c (8, 8, rep (10, 12), 10, 4, 1, 1))
  names (par) = c ('ITEM', 'TESTE', 'INTERCEPTO', 'ERRO_INTERCEPTO', 'PAR_A', 'ERRO_A', 'PAR_B', 'ERRO_B', 'CARGA_FATORIAL', 'ERRO_CARGA', 'PAR_C', 'ERRO_C',
                   'DRIFT', 'ERRO_DRIFT', 'NA', 'NUM_BILOG', 'RESP', 'NA2')
  par = par [, c(-15, -18)]
} else if (prog == 'MLM')
{
  par. = read.fwf(arq.par, widths = rep (12, categorias))
  par = par. [-dim(par.)[1],]
}
  return (par)
}
