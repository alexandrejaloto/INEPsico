#' @title Análise de DIF
#' @name dif
#'
#' @description Verifica existência de DIF e a qualidade do ajuste de um item calibrado no BILOG-MG
#' @param arq.exp arquivo .EXP gerado pelo BILOG-MG
#' @param arq.sco arquivo .SCO gerado pelo BILOG-MG
#' @param perc os percentis que definirão o intervalo de análise para detecção de DIF
#' @param dif.dif a diferença máxima tolerada entre a proporção de acerto observada e a esperada segundo o modelo
#' @param grupo o grupo, no arquivo .BLM, que está em análise; ou seja, o grupo focal corresponde a qual grupo no arquivo .BLM?
#' @param salvar argumento lógico que indica se a saída será salva em dois arquivos (um para DIF e outro para ajuste do modelo)
#'
#' @details Para analisar DIF, a função diminui a proporção de acerto do grupo focal da proporção de acerto
#'  do grupo de referência. Para verificar a qualidade do ajuste do item, a função diminui a probabilidade de
#'  acerto segundo o modelo da proporção de acerto observada.
#'  
#'  A função lê o arquivo expect; seleciona os itens comuns; seleciona o 
#' grupo de interesse e os outros grupos; compara os dois empíricos; seleciona
#'  o grupo de interesse; compara o teórico com o empírico
#'  
#'  ATENÇÃO: é necessário que o início do arquivo SCO tenha duas linhas que não são referentes a dados
#'
#' @return Uma lista com dois elementos:
#' 
#' $dif, que contém os itens que apresentaram DIF entre o grupo focal e algum outro grupo do BILOG-MG
#' 
#' $ajuste, que contém os itens que apresentaram problemas de ajuste
#'
#' @author Alexandre Jaloto
#'
#' @import LaF
#'
#' @export
dif = function (arq.exp, arq.sco, perc = list (5, 95), dif.dif = 0.15,
                grupo = 7, salvar = FALSE)
{
  dados = ler.exp (arq.exp)
  
  expect = as.data.frame(matrix (ncol = 43))
  tamanho.total = dim(dados)[1]
  
  # o loop vai até tamanho.total/48 porque são 8 colunas e seis variáveis (POINT, WEIGHT, TRIED, RIGHT,
  # PROPORTION, MODEL PROP)
  for (k in 1:(tamanho.total/48))
  {
    
    # ITEM
    expect [((k-1)*2+1),1] = as.character (dados [((k-1)*48+1),1])
    expect [((k-1)*2+2),1] = as.character (dados [((k-1)*48+1),1])
    
    # GRUPO
    expect [((k-1)*2+1),2] = dados [((k-1)*48+1),2]
    expect [((k-1)*2+2),2] = dados [((k-1)*48+1),2]
    
    # VARIÁVEL
    expect [((k-1)*2+1),3] = "PROPORCAO"
    expect [((k-1)*2+2),3] = "PROPORCAO_MODELO"
    
    for (i in 1:8)
    {
      # incluir os valores de proporção
      expect [((k-1)*2+1),((i-1)*5+4):((i-1)*5+8)] = dados [((k-1)*48+((i-1)*6+5)),4:8]
      
      # incluir os valores do modelo
      expect [((k-1)*2+2),((i-1)*5+4):((i-1)*5+8)] = dados [((k-1)*48+((i-1)*6+6)),4:8]
    }
  }
  
  names (expect) = c ("ITEM", "GRUPO", "VARIAVEL", dados [1, 4:8],
                      dados [7, 4:8], dados [13, 4:8], dados [19, 4:8],
                      dados [25, 4:8], dados [31, 4:8], dados [37, 4:8],
                      dados [43, 4:8])

  escore = ler.sco (arq.sco, prog = 'BLM')
  escore.g = subset (escore, Grupo == grupo)
  
  percentil.1a = quantile (escore.g$Proficiencia, as.numeric (perc[1])/100)
  percentil.2a = quantile (escore.g$Proficiencia, as.numeric (perc[2])/100)
  
  grupos = length (table (escore$Grupo))
  info.item = as.data.frame (table (expect$ITEM))
  
  
  #### FALTA SELECIONAR SOMENTE OS COMUNS DO GRUPO DE INTERESSE,
  #### POIS SELECIONEI TODOS OS COMUNS
  comuns = subset (info.item, Freq > 2)
  
  
  # selecionar as colunas do objeto expect que contêm os pontos de quadratura
  # dentro do intervalo
  int.ponto = expect [, c (T, T, T, (as.numeric (names(expect)[4:43]) >=
                                       percentil.1a & as.numeric (names(expect)[4:43])
                                     <= percentil.2a))]
  
  dif = as.data.frame (matrix (ncol = (grupos+1)))
  names (dif) = c ("Item    ", 1:(grupos-1), "DIF")
  
  for (i in 1:dim (comuns)[1])
  {
    
    item.comum = subset (int.ponto, ITEM == comuns[i,1] )
    
    dif[i,1] = as.character (comuns$Var1 [i])
    
    for (j in 1:(grupos-1))
    {
      
      comum1 = subset (item.comum, GRUPO == j)
      comum2 = subset (item.comum, GRUPO == grupo)
      
      dif1 = max (abs (comum1 [1, c (-1, -2, -3)] - comum2 [1, c (-1, -2, -3)]))
      
      if (!is.na (dif1))
      {
        dif[i,j+1] = as.numeric (sprintf ("%05g", dif1 ))
      }
      
      if (length (dif [i, c (F, !is.na (dif [i, c (-1, -(grupos+1))]))]) != 0)
      {
        dif[i,(grupos+1)] = ifelse (max (dif [i, c (F, !is.na (dif [i, c (-1, -(grupos+1))]))]) > dif.dif, 1, 0)
      }
      
    }
  }
  
  caso.dif = subset (dif, dif[,(grupos+1)] > 0)
  
  caso.dif [,1] = sprintf ("%08s", caso.dif [,1] )
  
  
  # AJUSTE
  # AJUSTE
  # AJUSTE
  # AJUSTE
  
  ajuste.g = subset (int.ponto, GRUPO == grupo)
  
  ajuste = as.data.frame (matrix (ncol = 3))
  names (ajuste) = c ("Item    ", "MC!ximo", "Ajuste")
  
  for (i in 1:(dim (ajuste.g)[1]/2))
  {
    aj = ajuste.g [1 + ((i-1)*2), c(-(1:3))] - ajuste.g [2 + ((i-1)*2), c(-(1:3))]
    
    ajuste [i,1] = ajuste.g [1 + ((i-1)*2),1]
    ajuste [i,2] = abs (as.numeric (sprintf ("%05g", max (aj) )))
    ajuste [i,3] = ifelse (max (aj) > dif.dif, 1, 0)
  }
  
  caso.ajuste = subset (ajuste, Ajuste > 0)
  
  caso.ajuste [,1] = sprintf ("%08s", caso.ajuste [,1] )
  
  
  if (salvar == TRUE)
  {
    write.table (caso.dif, "DIF.txt", sep = '\t', quote = F, row.names = F)
    write.table (caso.ajuste, "AJUSTE.txt", sep = '\t', quote = F, row.names = F)
  }
  
  casos = list(DIF = caso.dif, AJUSTE = caso.ajuste)
  return (casos)
}
