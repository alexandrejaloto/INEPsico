# ESTA FUNÇÃO ARREDONDA UM NÚMERO DA MESMA MANEIRA QUE O EXCEL E O SPSS
# arredonda de acordo com a norma 5891:2014 da ABNT
# multiplica x por 10^n
# trunca esse número
# diminui de x * 10^n
# se essa diferença for maior ou igual a 0.5, então arredonda para cima
# se essa diferença for menor do que 0.5, então arredonda para baixo


# x = número a ser arredondado
# n = número de casas decimais

arred = function (x, n)
{
if (x * (10 ^ n) - trunc (x * (10 ^ n)) >= .5) {trunc (x * (10 ^ n) + 1) / (10 ^ n)} else {trunc (x * (10 ^ n)) / (10 ^ n)}
}
