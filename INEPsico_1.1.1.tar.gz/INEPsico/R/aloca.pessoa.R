#' @title Alocação dos indivíduos nos níveis da escala
#' @name aloca.pessoa
#'
#' @description Alocar os indivíduos, de acordo com sua medida de tarço latente, nos níveis da escala
#'
#' @param escore Vetor com os escores dos indivíduos
#' @param niv Os níveis da escala
#' @param met O método de alocação, segundo o relatório de 2014 da ANAarq.par Arquivo PAR geado pelo BILOG-MG
#'
#' @details Utilize este campo para escrever detalhes mais tecnicos da
#'     sua funcao (se necessario), ou para detalhar melhor como
#'     utilizar determinados argumentos.
#'
#' @return A função retorna um objeto do tipo lista com dois elementos:
#'
#' $theta: A medida do traço latente dos indivíduos
#'
#' $niveis: O nível de cada indivíduo na escala
#'
#' @author Alexandre Jaloto
#'
#'
#' @examples
#' set.seed (12345)
#' escore = rnorm (100)
#' aloca.pessoa (escore)
#'
#' @export
aloca.pessoa = function (escore, niv = seq (-2, 2, .25), met = 3)
{
  score = list()
  score$theta = escore

  # caso o método para alocação seja o da opção 1 do relatório da ANA 2014
    if (met == 1)
  {
      score$niveis = data.frame (cut (score$theta, c (-Inf, niv), labels = niv))

  # caso o método para alocação seja o da opção 3 do relatório da ANA 2014
  } else if (met == 3) {
      score$niveis = data.frame (cut (score$theta, c (-Inf, niv), labels = niv))
  }
  score$theta = data.frame (score$theta)

  names (escore$theta) = "Escore"
  names (score$niveis) = "Nivel"
  return (score)
}
