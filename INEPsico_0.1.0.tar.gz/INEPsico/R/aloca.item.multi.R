# esta função aloca os itens politômicos nos níveis
# par = data.frame com os parâmetros dos itens (lido pela função ler.par.multi)
# categorias = o maior quantitativo de categorias de um mesmo item
# p = a probabilidade de obter determinado código (categoria) utilizada para alocar o item em um nível
# m = média da escala transformada (o padrão da função é não transformar)
# dp = desvio padrão da escala transformada (o padrão da função é não transformar)
# int.dp = os níveis variam de quanto em quanto, em relação ao dp?
# int.nivel = o nível mais baixo e o nível mais alto
# met = o método de alocação, segundo o relatório de 2014 da ANA
# nomes.cat = data.frame ou matrix indicando o nome de cada categoria de cada item (nesta data.frame, se a categoria não existir em determinado item, indicar NA)

aloca.item.multi = function (par, categorias, p = .65, m = 0,
                             dp = 1, int.dp = .25, int.nivel = c (-2, 2),
                             met = 3, nomes.cat = FALSE)
{
# ler arquivo PAR
# par = ler.par.multi(arq.par, categorias)

# verificar número de itens
n.item = dim (par)[1]

# objeto com valores de parâmetro a
a = par [1:n.item,1]

# objeto com valores de parâmetro b
b = par [1:n.item,-1]

# calcular o theta correspondente a p para acertar o item e alocar os itens nos níveis de acordo com a opção de método escolhida
theta = list()
theta$prof = (- log ((1-p)/p)/a + b)*dp + m
prof.min = min (theta$prof [is.na(theta$prof)==F])
prof.max = max (theta$prof [is.na(theta$prof)==F])

theta$niveis = as.data.frame(matrix(nrow = nrow(theta$prof)))

# caso o método para alocação seja o da opção 1 do relatório da ANA 2014
if (met == 1)
{
for (i in 1:(categorias-1))
{
  theta$niveis[,i] = cut (theta$prof[,i], c (-Inf, seq (int.nivel[1]+int.dp*dp/2, int.nivel[2]+int.dp*dp/2, int.dp*dp)), labels = seq (int.nivel[1], int.nivel[2], int.dp*dp))
}

# caso o método para alocação seja o da opção 3 do relatório da ANA 2014
} else if (met == 3) {
  for (i in 1:(categorias-1))
{
  theta$niveis[,i] = cut (theta$prof[,i], c (-Inf, seq (int.nivel[1], int.nivel[2], int.dp*dp)), labels = seq (int.nivel[1], int.nivel[2], int.dp*dp))
}
}

# quantidade de níveis
n.niv = length(seq (int.nivel[1], int.nivel[2], int.dp*dp))

theta$MaiorProb = as.data.frame (matrix(ncol = n.niv, nrow = n.item))
names (theta$MaiorProb) = seq (int.nivel[1], int.nivel[2], int.dp*dp)

# a categoria de maior probabilidade será:
# se o nome da variável (que é o nível) for menor do que o nível da categoria mais fácil do item
# então será a 'cat1'; se não for, então será a 'cat' que tem nível igual ao nível em questão

# i é o item
for (i in 1:n.item)
{
# j é o nível
for (j in 1:n.niv)
{
theta$MaiorProb [i,j] = ifelse (names (theta$MaiorProb)[j] <
                                  min (theta$niveis[i,] [is.na(theta$niveis[i,])==F]),
                                'cat1', paste('cat', ((which(theta$niveis[i,] == names (theta$MaiorProb)[j]) + 1)), sep = ""))
}
}
# trocar 'cat' pela categoria correspondente
for (i in 1:n.item)
{
  for (j in 1:n.niv)
  {

theta$MaiorProb [i,j] = ifelse (theta$MaiorProb [i,j] == 'cat', theta$MaiorProb [i,(j-1)], theta$MaiorProb [i,j])
  }
}
if (class (nomes.cat)=='data.frame' | class (nomes.cat)=='matrix')
{

# número de algarismos da quantidade de categorias
n.dig = ifelse (categorias<10, 1, 2)

# i é o item
for (i in 1:n.item)
{

# j é o nível
for (j in 1:n.niv)
{

# retornar o número da categoria que será substituída nesta rodada do loop
n.cat = as.numeric (substr(theta$MaiorProb [i,j],4,n.dig+4))

# categoria correspondente ao item i, categoria n.cat
cat. = as.character (nomes.cat [i, n.cat])

# substituindo a 'cat' + i pela categoria correspondente da data.frame cat
theta$MaiorProb [i,j] = cat.
}
}
}
return(theta)
}
