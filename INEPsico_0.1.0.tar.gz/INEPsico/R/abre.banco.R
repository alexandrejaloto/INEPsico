# ESTA FUNÇÃO ABRE O BANCO
# banco = objeto que tem a variável correspondente ao caderno e as variáveis correspondentes às espostas aos itens
# arq.itens = os arquivos com os itens das disciplinas que compõem os cadernos no BIB (tem que ser todos, por enquanto; depois tem que melhroar a função)
# disc = qual será a disciplina desse banco?
# disc.cad = quantidade de disciplinas em cada caderno
# arq.bib = arquivo com o BIB
# a função retorna uma lista com dois elementos: 'respostas' e 'gabarito'

abre.banco = function (banco, arq.itens, arq.bib, disc, disc.cad = 2)

{
estrutura = gera.caderno (arq.itens, arq.bib, disc.cad)[[disc]]

# número total de cadernos
tot.cad = max (estrutura$Caderno)

# criar objeto 'aberto.' que será a base para o objeto final 'aberto'.
# o que será feito: um loop para pegar os respondentes de cada caderno; nomeação das
# variáveis de acordo com os códigos dos itens; rbind pelo data.table para juntar cada
# objeto de cada loop

aberto. = data.table::as.data.table(data.frame())
for (i in 1:tot.cad)
{
resp = data.table::as.data.table (subset (banco, banco[,1] == i))
cad = subset (estrutura, Caderno == i)
names (resp) = c ('CADERNO', cad$Item)
aberto. = rbind(aberto., resp, fill = TRUE)
}
aberto = list()
aberto$respostas = data.frame (aberto.)
names (aberto$respostas) = names (aberto.)
rm (aberto.)

# agora abrir o gabarito
# criar objeto com os códigos dos itens (sem repetição)
aberto[['gabarito']] = data.frame (Item = unique(estrutura$Item))

# fazer um loop para pegar cada item desse objeto e fazer tipo um procv no objeto
# 'estrutura'
for (i in 1:length (aberto[['gabarito']]$Item))
{
cod = aberto[['gabarito']]$Item[i]
aberto[['gabarito']]$Gabarito[i] = estrutura$Gabarito [which(estrutura$Item == cod)[1]]
}

return (aberto)
}
